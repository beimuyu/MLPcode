Due to confidentiality reasons, all data cannot be provided.
The pump characteristic data in the source field is for a small single-stage centrifugal pump 
with a rated flow rate of 25m3/h, head of 32m, and rated speed of 2980rpm
Training can be conducted on this basis