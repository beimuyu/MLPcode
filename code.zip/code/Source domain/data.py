
import pandas as pd
import numpy as np
import torch
from sklearn.model_selection import train_test_split

def process_data():
    # 读取CSV文件中的数据
    input_table = pd.read_csv('input_data.csv', dtype=np.float32)

    # 提取数据列
    speeds = input_table['Speeds'].values
    torques = input_table['Flows'].values
    heads = input_table['Heads'].values
    #efficiencies = input_table['Efficiencies'].values
    # 数据归一化
    speeds /= 3500  # 转速归一化
    torques /= 50  # 流量
    heads /= 50   # 扬程
    #efficiencies /= 48.2   # 效率

    # 整理输入和输出数据
    inputs = np.column_stack((speeds, torques))
    #outputs = np.column_stack((heads, efficiencies))  #修改输出维数时，记得改神经网络结构！
    outputs = heads.reshape(-1, 1)

    # 将数据转换为张量
    inputs = torch.tensor(inputs, dtype=torch.float32)
    outputs = torch.tensor(outputs, dtype=torch.float32)

    # 将数据集分割成训练集和测试集
    inputs_train, inputs_test, outputs_train, outputs_test = train_test_split(inputs, outputs, test_size=0.2, random_state=10)

    # 输出分割后的训练集和测试集的大小
    print("训练集大小:", inputs_train.shape, outputs_train.shape)
    print("测试集大小:", inputs_test.shape, outputs_test.shape)
    return inputs_train, inputs_test, outputs_train, outputs_test

if __name__ == "__main__":
    process_data()
