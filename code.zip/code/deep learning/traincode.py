import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
#调用神经网络结构文件
from MLP5 import MLP
from data import process_data
import random
import os
seed_value = 42   # 设定随机数种子 42 3407

np.random.seed(seed_value)
random.seed(seed_value)
os.environ['PYTHONHASHSEED'] = str(seed_value)  
torch.manual_seed(seed_value)     # 为CPU设置随机种子
torch.backends.cudnn.deterministic = True


# 调用process_data函数并接收返回的训练集和测试集数据
inputs_train, inputs_test, outputs_train, outputs_test = process_data()

# 定义训练参数
learning_rate = 0.01
num_epochs = 100
batch_size = 16
#save_file='stock.pkl'

# 创建模型实例和损失函数
model = MLP()
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=learning_rate)

#记录训练时间
import time
start = time.time()

losses = []  # 用于记录每个epoch的损失值
# 进行训练
for epoch in range(num_epochs):
    # 将数据分成小批次进行训练
    permutation = torch.randperm(inputs_train.size()[0])
    for i in range(0, inputs_train.size()[0], batch_size):
        indices = permutation[i:i+batch_size]
        batch_inputs, batch_outputs = inputs_train[indices], outputs_train[indices]
        # 前向传播
        outputs_pred = model(batch_inputs)

        # 计算损失
        loss = criterion(outputs_pred, batch_outputs)

        # 反向传播和优化
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    losses.append(loss.item())  # 记录损失值
    if (epoch + 1) % 10 == 0:
        print(f'Epoch:{epoch + 1}/{num_epochs}, Loss: {loss.item():.16f}')
    # 保存训练过程中的loss曲线的数据点到losses.csv文件
    np.savetxt('losses.csv', np.array(losses), delimiter=',')

#记录训练时间
end = time.time()
print('训练时间：', end - start)        

# 进行测试
model.eval()
with torch.no_grad():
    outputs_pred = model(inputs_test)
    test_loss = criterion(outputs_pred, outputs_test)
    print('Test loss:', test_loss.item())

# 保存整个模型
torch.save(model, 'model.pth')
# 保存模型参数
torch.save(model.state_dict(), 'params.pth')  


# 绘制损失曲线
plt.plot(losses)
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Training Loss')
plt.show()

test_df = pd.read_csv("test_data.csv")  # 读取表格文件
test_tensor = torch.tensor(test_df.values, dtype=torch.float32)

with torch.no_grad():
    predicted_output = model(test_tensor) * 50.47

test_df["predicted_output"] = predicted_output.numpy()
test_df.to_csv("test_results.csv", index=False)

print("预测结果保存至test_results.csv")
